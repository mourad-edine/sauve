module.exports = [
"[project]/.next-internal/server/app/service/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_service_page_actions_b935dde1.js.map